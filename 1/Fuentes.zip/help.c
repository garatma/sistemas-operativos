#include <stdio.h>

// muestra un mensaje por pantalla con la descripción de los comandos.
int main() {
    printf("Los comandos que ofrece la terminal son:\n- mkdir [nombre_directorio]: crea un directorio con el nombre especificado.\n- lsdir [nombre_directorio]: lista el contenido del directorio especificado por pantalla.\n- rmdir [nombre_directorio]: elimina el directorio especificado y su contenido.\n- mkfil [nombre_archivo]: crea un archivo con el nombre especificado.\n- lsfil [nombre_archivo]: lista el contenido del archivo especificado por pantalla.\n- exit: finaliza la ejecución de la terminal.\n");


    return 0;
}
